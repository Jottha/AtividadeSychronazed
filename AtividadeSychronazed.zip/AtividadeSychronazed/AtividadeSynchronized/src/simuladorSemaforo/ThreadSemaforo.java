package simuladorSemaforo;

public class ThreadSemaforo {

}
